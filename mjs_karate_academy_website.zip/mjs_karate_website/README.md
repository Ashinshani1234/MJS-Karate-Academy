# MJS Karate Academy - Digital Transformation Web System

Welcome to the **MJS Karate Academy** official website and database-free web management system! Designed for Chief Instructor **Sensei Jayasinghe Herath** (International Black Belt 5th Dan), coaches **Ashinshani Menaka** and **Dilshan Isuru**, students, and parents.

---

## 🥋 Key Features & Interactive Highlights

### 1. Opening Dojo Door Entrance Sequence
- **Animated Entrance**: Upon visiting the site, an interactive Dojo Door sequence displays the **MJS KARATE ACADEMY** title, Chief Sensei Jayasinghe Herath, coaches Ashinshani Menaka & Dilshan Isuru, and male & female black belt students giving a traditional bow with an **"OSS!"** greeting.

### 2. Karate Punch & Kick Portal Navigation
- **Dynamic Portal Transitions**: Section switching is driven by high-energy martial arts technique animation overlays:
  - **Gyaku Zuki** (Reverse Punch)
  - **Mae Geri** (Front Kick)
  - **Ura Mawashi Geri** (Hook Kick)
  - **Jumping Flying Kick**

### 3. Red, Blue & White Athletic Sports CSS Theme
- High-contrast, dynamic sports aesthetic featuring angled card containers, sports badge tags, high-visibility status indicators, and responsive mobile layout.

### 4. Smart QR Code Attendance System (Laptop Scanner Mode)
- **Role-Restricted Security**: Attendance data access is strictly restricted to **Chief Sensei Jayasinghe Herath** and Coaches **Ashinshani Menaka & Dilshan Isuru**.
- **QR Student Registration**: Dynamically generates a student ID badge with an embedded QR code upon registering a new student.
- **Laptop Scanner Simulator**: Allows scanning or clicking quick-scan QR badges on the laptop camera screen to automatically log attendance with real-time timestamps.

### 5. Protected Fee Management & Automated Parent SMS Receipts
- **Role-Restricted View**: Fee details are hidden from the public and accessible only to verified **Parents** and **Chief Sensei Jayasinghe Herath**.
- **Automated SMS Receipts**: When a monthly fee payment is processed, an automated SMS notification popup modal is generated and delivered to the parent's phone number.

### 6. Separate Dedicated Admin Dashboard
- **Full System Editability**: Complete administrative control panel to:
  - Edit student names, belt ranks, and parent contact numbers.
  - Delete or modify student rosters.
  - Override fee statuses and send instant SMS updates.
  - Manage and clear daily attendance logs.
  - Update master Dojo configuration settings.

---

## 🚀 How to Run & Deploy (Database-Free)

Because this web system is entirely **database-free** and powered by HTML5, CSS3, and modern client-side JavaScript, it runs standalone in any browser with zero setup or backend installation!

### Local Run:
1. Extract all files from `mjs_karate_academy_website.zip`.
2. Double-click `index.html` to open it in Chrome, Firefox, Edge, or Safari.

### Web Server / Hosting Deployment:
- Simply upload the contents of the unzipped folder (`index.html`, `css/`, `js/`, `assets/`) to any static host (GitHub Pages, Netlify, Vercel, or traditional cPanel web hosting).

---

## 📁 Directory Structure

```
mjs_karate_website/
├── index.html        # Main HTML structure with Dojo Entrance & Portal Sections
├── css/
│   └── styles.css    # Athletic red/blue/white sports styling & strike keyframes
├── js/
│   └── script.js     # Autonomous JS engine (QR Generator, Scanner, Fees, SMS, Admin)
└── README.md         # Full System Documentation
```

---
*Developed for MJS Karate Academy - Empowering Martial Arts Excellence through Technology.*
