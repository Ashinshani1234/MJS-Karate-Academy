// MJS KARATE ACADEMY SYSTEM JAVASCRIPT

// INITIAL DATA STORE
let academyData = {
    students: [
        { id: "MJS-101", name: "Kasun Kalhara", belt: "Black Belt", phone: "+94 77 123 4567", feeStatus: "Paid", feeAmount: "LKR 3,500" },
        { id: "MJS-102", name: "Dilini Perera", belt: "Brown Belt", phone: "+94 71 987 6543", feeStatus: "Pending", feeAmount: "LKR 3,500" },
        { id: "MJS-103", name: "Sahan Ranasinghe", belt: "Green Belt", phone: "+94 75 456 7890", feeStatus: "Paid", feeAmount: "LKR 3,000" },
        { id: "MJS-104", name: "Nimesha Jayawardena", belt: "Yellow Belt", phone: "+94 78 333 4444", feeStatus: "Paid", feeAmount: "LKR 3,000" }
    ],
    attendance: [
        { studentId: "MJS-101", name: "Kasun Kalhara", belt: "Black Belt", time: "08:15 AM", status: "Present", loggedBy: "Laptop QR Scanner" },
        { studentId: "MJS-103", name: "Sahan Ranasinghe", belt: "Green Belt", time: "08:22 AM", status: "Present", loggedBy: "Laptop QR Scanner" }
    ],
    systemConfig: {
        chiefSensei: "Sensei Jayasinghe Herath (International Black Belt 5th Dan)",
        coaches: ["Ashinshani Menaka", "Dilshan Isuru"]
    }
};

// DOM CONTENT LOADED INITIALIZATION
document.addEventListener("DOMContentLoaded", () => {
    renderAttendanceLog();
    renderFeeTable();
    renderQuickScanButtons();
    renderAdminRoster();
    renderAdminFees();
});

// DOJO ENTRANCE ANIMATION TRIGGER
function enterDojo() {
    const dojoOverlay = document.getElementById("dojoEntranceOverlay");
    const ossBubble = document.getElementById("ossBubble");
    
    ossBubble.innerHTML = "<span>\"OSS! DOJO DOORS OPENING...\"</span>";

    setTimeout(() => {
        dojoOverlay.classList.add("doors-opened");
        setTimeout(() => {
            dojoOverlay.classList.add("closed-dojo");
        }, 1000);
    }, 400);
}

// PUNCH & KICK PORTAL ANIMATION NAVIGATOR
function triggerPortal(targetSectionId, techniqueName) {
    const portalOverlay = document.getElementById("portalOverlay");
    const strikeText = document.getElementById("strikeText");
    const strikeGraphic = document.getElementById("strikeGraphic");

    strikeText.innerText = techniqueName.toUpperCase() + "!";
    
    // Choose icon based on kick vs punch
    if (techniqueName.toLowerCase().includes("kick")) {
        strikeGraphic.innerHTML = '<i class="fa-solid fa-person-running"></i>';
    } else {
        strikeGraphic.innerHTML = '<i class="fa-solid fa-hand-fist"></i>';
    }

    // Show strike overlay
    portalOverlay.classList.add("active-strike");

    setTimeout(() => {
        // Switch section
        document.querySelectorAll(".portal-section").forEach(sec => sec.classList.remove("active-section"));
        document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));
        
        const targetSec = document.getElementById(targetSectionId);
        if (targetSec) targetSec.classList.add("active-section");

        // Hide portal overlay
        portalOverlay.classList.remove("active-strike");
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 600);
}

// ATTENDANCE RESTRICTED ACCESS
function unlockAttendance(staffName) {
    document.getElementById("currentStaffUser").innerText = staffName;
    document.getElementById("attendanceAuthGate").classList.add("hidden-panel");
    document.getElementById("attendanceMainArea").classList.remove("hidden-panel");
}

function lockAttendance() {
    document.getElementById("attendanceAuthGate").classList.remove("hidden-panel");
    document.getElementById("attendanceMainArea").classList.add("hidden-panel");
}

// FEE PORTAL RESTRICTED ACCESS
function unlockFees(userRole) {
    document.getElementById("currentFeeUser").innerText = userRole;
    document.getElementById("feesAuthGate").classList.add("hidden-panel");
    document.getElementById("feesMainArea").classList.remove("hidden-panel");
}

function lockFees() {
    document.getElementById("feesAuthGate").classList.remove("hidden-panel");
    document.getElementById("feesMainArea").classList.add("hidden-panel");
}

// REGISTER NEW STUDENT & GENERATE QR CODE BADGE
function registerStudent(e) {
    e.preventDefault();
    const name = document.getElementById("regName").value;
    const belt = document.getElementById("regBelt").value;
    const phone = document.getElementById("regPhone").value;
    
    const newId = "MJS-" + (100 + academyData.students.length + 1);
    
    const newStudent = {
        id: newId,
        name: name,
        belt: belt,
        phone: phone,
        feeStatus: "Pending",
        feeAmount: "LKR 3,500"
    };

    academyData.students.push(newStudent);

    // Generate QR Code inside canvas container
    const qrcodeContainer = document.getElementById("qrcodeCanvas");
    qrcodeContainer.innerHTML = "";
    new QRCode(qrcodeContainer, {
        text: newId + " | " + name,
        width: 140,
        height: 140
    });

    document.getElementById("badgeStudentName").innerText = name;
    document.getElementById("badgeStudentId").innerText = "ID: " + newId + " (" + belt + ")";
    document.getElementById("newQrBadgeResult").classList.remove("hidden-panel");

    // Refresh UI components
    renderQuickScanButtons();
    renderAdminRoster();
    renderFeeTable();
    renderAdminFees();

    document.getElementById("qrRegForm").reset();
}

// RENDER QUICK SCAN BUTTONS FOR LAPTOP SCANNER SIMULATOR
function renderQuickScanButtons() {
    const scanContainer = document.getElementById("quickScanButtons");
    scanContainer.innerHTML = "";
    academyData.students.forEach(st => {
        const btn = document.createElement("button");
        btn.className = "btn-scan-demo";
        btn.innerHTML = `<i class="fa-solid fa-qrcode"></i> Scan ${st.name} (${st.id})`;
        btn.onclick = () => scanQrDemo(st.id);
        scanContainer.appendChild(btn);
    });
}

// LAPTOP QR CODE SCAN SIMULATION
function scanQrDemo(studentId) {
    const student = academyData.students.find(s => s.id === studentId);
    if (!student) return;

    // Check if already logged
    const existing = academyData.attendance.find(a => a.studentId === studentId);
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    if (!existing) {
        academyData.attendance.unshift({
            studentId: student.id,
            name: student.name,
            belt: student.belt,
            time: timeNow,
            status: "Present",
            loggedBy: "Laptop QR Scanner"
        });
        alert(`✅ QR CODE SCANNED!\nStudent: ${student.name}\nAttendance Marked: Present (${timeNow})`);
    } else {
        alert(`ℹ️ STUDENT ALREADY SCANNED!\n${student.name} was already marked present at ${existing.time}.`);
    }

    renderAttendanceLog();
}

// RENDER ATTENDANCE TABLE
function renderAttendanceLog() {
    const tbody = document.getElementById("attendanceLogTable");
    const adminTbody = document.getElementById("adminAttendanceBody");
    tbody.innerHTML = "";
    adminTbody.innerHTML = "";

    academyData.attendance.forEach(log => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td><strong>${log.studentId}</strong></td>
            <td>${log.name}</td>
            <td>${log.belt}</td>
            <td>${log.time}</td>
            <td><span class="status-tag present">PRESENT</span></td>
            <td><small>${log.loggedBy}</small></td>
        `;
        tbody.appendChild(tr);

        const trAdmin = document.createElement("tr");
        trAdmin.innerHTML = `
            <td>${log.name} (${log.studentId})</td>
            <td>${log.time}</td>
            <td><span class="status-tag present">PRESENT</span></td>
        `;
        adminTbody.appendChild(trAdmin);
    });
}

// RENDER FEE TABLE & PARENT SMS RECEIPT TRIGGER
function renderFeeTable() {
    const tbody = document.getElementById("feeTableBody");
    tbody.innerHTML = "";

    academyData.students.forEach(st => {
        const tr = document.createElement("tr");
        const isPaid = st.feeStatus === "Paid";
        const statusBadge = isPaid 
            ? '<span class="status-tag paid">PAID</span>' 
            : '<span class="status-tag pending">PENDING</span>';
        
        const actionBtn = isPaid
            ? `<button class="btn-scan-demo" onclick="triggerParentSms('${st.name}', '${st.phone}', '${st.feeAmount}')"><i class="fa-solid fa-comment-sms"></i> Resend SMS</button>`
            : `<button class="btn-primary-sports" style="padding: 6px 12px; font-size:0.8rem;" onclick="payFee('${st.id}')"><i class="fa-solid fa-credit-card"></i> Pay & Send SMS</button>`;

        tr.innerHTML = `
            <td><strong>${st.id}</strong></td>
            <td>${st.name} (${st.belt})</td>
            <td>${st.phone}</td>
            <td>${st.feeAmount}</td>
            <td>${statusBadge}</td>
            <td>${actionBtn}</td>
        `;
        tbody.appendChild(tr);
    });
}

// SIMULATE PAYMENT AND TRIGGER SMS
function payFee(studentId) {
    const student = academyData.students.find(s => s.id === studentId);
    if (student) {
        student.feeStatus = "Paid";
        renderFeeTable();
        renderAdminFees();
        triggerParentSms(student.name, student.phone, student.feeAmount);
    }
}

function triggerParentSms(studentName, phone, amount) {
    const smsModal = document.getElementById("smsModal");
    const smsText = document.getElementById("smsBubbleText");

    smsText.innerText = `Dear Parent, monthly fee payment of ${amount} received for ${studentName}. Verified by Chief Sensei Jayasinghe Herath (5th Dan), MJS Karate Academy. Thank you!`;
    
    smsModal.classList.add("active-sms");
}

function closeSmsModal() {
    document.getElementById("smsModal").classList.remove("active-sms");
}

// ADMIN DASHBOARD TAB SWITCHER
function switchAdminTab(tabId) {
    document.querySelectorAll(".admin-tab-pane").forEach(pane => pane.classList.remove("active-pane"));
    document.querySelectorAll(".admin-tab-btn").forEach(btn => btn.classList.remove("active"));
    
    document.getElementById(tabId).classList.add("active-pane");
    event.currentTarget.classList.add("active");
}

// ADMIN ROSTER EDITING
function renderAdminRoster() {
    const tbody = document.getElementById("adminStudentRoster");
    tbody.innerHTML = "";

    academyData.students.forEach((st, idx) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${st.id}</td>
            <td><input type="text" value="${st.name}" onchange="updateStudentName(${idx}, this.value)" style="padding:4px; border-radius:4px; border:1px solid #ccc;"></td>
            <td>
                <select onchange="updateStudentBelt(${idx}, this.value)" style="padding:4px;">
                    <option value="White Belt" ${st.belt==='White Belt'?'selected':''}>White Belt</option>
                    <option value="Yellow Belt" ${st.belt==='Yellow Belt'?'selected':''}>Yellow Belt</option>
                    <option value="Green Belt" ${st.belt==='Green Belt'?'selected':''}>Green Belt</option>
                    <option value="Brown Belt" ${st.belt==='Brown Belt'?'selected':''}>Brown Belt</option>
                    <option value="Black Belt" ${st.belt==='Black Belt'?'selected':''}>Black Belt</option>
                </select>
            </td>
            <td><input type="text" value="${st.phone}" onchange="updateStudentPhone(${idx}, this.value)" style="padding:4px; border-radius:4px; border:1px solid #ccc;"></td>
            <td><button style="background:#EF4444; color:#FFF; border:none; padding:4px 8px; border-radius:4px; cursor:pointer;" onclick="deleteStudent(${idx})"><i class="fa-solid fa-trash"></i></button></td>
        `;
        tbody.appendChild(tr);
    });
}

function updateStudentName(idx, val) { academyData.students[idx].name = val; refreshAllUI(); }
function updateStudentBelt(idx, val) { academyData.students[idx].belt = val; refreshAllUI(); }
function updateStudentPhone(idx, val) { academyData.students[idx].phone = val; refreshAllUI(); }
function deleteStudent(idx) {
    if (confirm("Delete this student record?")) {
        academyData.students.splice(idx, 1);
        refreshAllUI();
    }
}

function renderAdminFees() {
    const tbody = document.getElementById("adminFeeEditBody");
    tbody.innerHTML = "";
    academyData.students.forEach(st => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${st.id}</td>
            <td>${st.name}</td>
            <td>${st.feeAmount}</td>
            <td>${st.feeStatus}</td>
            <td>
                <button class="btn-scan-demo" onclick="payFee('${st.id}')">Toggle Paid & SMS</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function refreshAllUI() {
    renderAttendanceLog();
    renderFeeTable();
    renderAdminRoster();
    renderAdminFees();
    renderQuickScanButtons();
}

function resetTodayAttendance() {
    if (confirm("Reset today's attendance logs?")) {
        academyData.attendance = [];
        renderAttendanceLog();
    }
}

function saveSystemSettings() {
    alert("✅ Dojo Master Settings saved successfully!");
}
